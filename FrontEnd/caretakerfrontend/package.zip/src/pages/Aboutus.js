export default function Aboutus() {
  return (
    <div className="mt-3 mx-auto p-4 text-center" style={{width:"96%",background:"white"}}>
      <div className="fw-bold fs-2" id="aboutus">About Oldster Care Provider</div>
      <p className='px-5'> Launched in 2022, Oldster Care Provider is India’s No.1 online old age care provider.
      </p>
    </div>
  );
}
